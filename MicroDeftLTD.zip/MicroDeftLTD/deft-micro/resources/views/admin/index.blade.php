<!DOCTYPE html>
<html lang="en">
<head>
    <title>Microdeft</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

    <h1 class="text-center mt-3">Products</h1>
    <div class="container">
        <div class="row mt-4">
            <div class="col-md-6 mx-auto">
                <form class="form-horizontal p-t-20" method="POST" action="">
                    @csrf
                    <div class="form-group row">
                        <label for="exampleInputuname3" class="col-sm-3 control-label">product Name <span class="text-danger">*</span></label>
                        <div class="col-sm-9">

                            <input type="text" class="form-control" name="name" id="exampleInputuname3" placeholder="product Name">

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="form4Example3" class="col-sm-3 control-label">product Description <span class="text-danger">*</span></label>
                        <div class="col-sm-9">

                            <textarea type="text" name="description" class="form-control" id="exampleInputEmail3" placeholder="product Description" rows="4"></textarea>

                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="form-label col-sm-3 control-label" for="web">product Image <span class="text-danger">*</span></label>
                        <div class="col-sm-9">

                                <input type="file" name="image" id="input-file-now" class="dropify" />

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="exampleInputEmail3" class="col-sm-3 control-label">Publication Status <span class="text-danger">*</span></label>
                        <div class="col-sm-9">
                            <label class="me-3"><input type="radio" name="status" value="1" checked> Published </label>
                            <label><input type="radio" name="status" value="2"> Unpublished </label>
                        </div>
                    </div>
                    <div class="form-group row m-b-0">
                        <div class="offset-sm-3 col-sm-9">
                            <button type="submit" class="btn btn-success waves-effect waves-light text-white">Create New product</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>
</html>
